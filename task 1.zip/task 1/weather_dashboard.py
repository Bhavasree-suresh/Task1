import requests
import matplotlib.pyplot as plt
import seaborn as sns
import datetime

# Constants
API_KEY = 'f15fb656207aa02d2130e796f6f38b41' # Replace with your actual key
CITY = 'Chennai'
UNITS = 'metric'  # or 'imperial'
URL = f'https://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units={UNITS}'

# Fetch API data
response = requests.get(URL)
data = response.json()

# Check for error
if response.status_code != 200:
    print("Error fetching data:", data.get("message"))
    exit()

# Extract relevant data
dates, temperatures, humidities, wind_speeds = [], [], [], []
for entry in data['list']:
    dt = datetime.datetime.strptime(entry['dt_txt'], '%Y-%m-%d %H:%M:%S')
    temp = entry['main']['temp']
    humidity = entry['main']['humidity']
    wind = entry['wind']['speed']

    dates.append(dt)
    temperatures.append(temp)
    humidities.append(humidity)
    wind_speeds.append(wind)

# Set seaborn style
sns.set(style="whitegrid")

# Plot 1: Temperature Forecast
plt.figure(figsize=(10, 5))
sns.lineplot(x=dates, y=temperatures, color="orange")
plt.title(f"Temperature Forecast for {CITY}")
plt.xlabel("Date-Time")
plt.ylabel("Temperature (°C)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Plot 2: Humidity Forecast
plt.figure(figsize=(10, 5))
sns.lineplot(x=dates, y=humidities, color="blue")
plt.title(f"Humidity Forecast for {CITY}")
plt.xlabel("Date-Time")
plt.ylabel("Humidity (%)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Plot 3: Wind Speed Forecast
plt.figure(figsize=(10, 5))
sns.lineplot(x=dates, y=wind_speeds, color="green")
plt.title(f"Wind Speed Forecast for {CITY}")
plt.xlabel("Date-Time")
plt.ylabel("Wind Speed (m/s)")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
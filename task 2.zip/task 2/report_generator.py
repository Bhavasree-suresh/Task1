import pandas as pd
from fpdf import FPDF

df = pd.read_csv("data.csv")
average = df["Marks"].mean()

pdf = FPDF()
pdf.add_page()
pdf.set_font("Arial", size=12)
pdf.cell(200, 10, txt="Student Marks Report", ln=1, align='C')
pdf.ln(10)

for index, row in df.iterrows():
    pdf.cell(200, 10, txt=f"{row['Name']} - {row['Marks']}", ln=1)

pdf.ln(10)
pdf.cell(200, 10, txt=f"Average Marks: {average:.2f}", ln=1)
pdf.output("report.pdf")
